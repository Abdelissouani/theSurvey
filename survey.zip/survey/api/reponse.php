<?php
  // Se connecter à la base de données
  include("db_connection.php");
  $request_method = $_SERVER["REQUEST_METHOD"];
  switch($request_method){
    case 'POST':
        addQuestion();
        break;
    case
        'GET':
        getQuestions();
        break;
    default:
      header("HTTP/1.0 405 Method Not Allowed");
      break;
  }
  function addReponse()){
    global $bdd;
   
    foreach($_POST as $key => $value){
        $id_question=$value['id_question'];
        $type_reponse=$value['type_reponse'];
        $reponse=$value['reponse'];
        if($type_reponse=='scale'){
            $reponse=$bdd->exec("INSERT INTO reponse (id_question,reponse_scale) VALUES($id_question,$reponse)");
        }else{
            $reponse=$bdd->exec("INSERT INTO reponse (id_question,reponse_text) VALUES($id_question,'".$reponse."')");
        }
    }
}
function getReponse(){
    global $bdd;
    $id_question=$_GET['id_question'];
    $result=$bdd->query("SELECT * from reponse Where id_question=$id_question");
    $result=$result->fetchAll();
    header('Content-Type: application/json');
    echo json_encode($result);
}

