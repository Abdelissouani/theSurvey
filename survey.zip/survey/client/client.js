$.ajax({
    url : "../API/question.php",
}).done(function(result){ 
      result.forEach(element => {console.log(element['intitule'])
          
      });
});	