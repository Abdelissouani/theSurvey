<?php
  // Se connecter à la base de données
  include("db_connection.php");
  $request_method = $_SERVER["REQUEST_METHOD"];
  switch($request_method){
    case 'POST':
        addQuestion();
        break;
    case
        'GET':
        getQuestions();
        break;
    case 'PUT':
        updateQuestion();
        break; 
    default:
      header("HTTP/1.0 405 Method Not Allowed");
      break;
  }
  function addQuestion(){
    global $bdd;
    $intitule=$_POST['intitule'];
    if($_POST['actif']==true){
        $actif=1;
    }else{
        $actif=0;
    }
    $type_reponse=$_POST['type_reponse'];
    $reponse=$bdd->exec("INSERT INTO question (intitule,actif,type_reponse) VALUES('".$intitule."',". $actif.",'".$type_reponse."')");
    $id_question= $bdd->lastInsertId();

  if($correct){
    $response=array(
      'status' => 1,
      'status_message' =>'info ajoute avec succes.'
    );
  }
  else{
    $response=array(
      'status' => 0,
      'status_message' =>'ERREUR!'. mysqli_error($dbb)
    );
  }
  header('Content-Type: application/json');
  echo json_encode($response);
}
function getQuestions(){
    global $bdd;
    $result=$bdd->query("SELECT * from question Where actif=1");
    $result=$result->fetchAll();
    header('Content-Type: application/json');
    echo json_encode($result);
}
function updateQuestion(){
    $_PUT = array();
    parse_str(file_get_contents("php://input"), $_PUT);
    foreach ($_PUT as $key => $value)
    {
        echo $key . " : " . $value;
    }
    $id_question=$_Put[id_question];
    $reponse=$bdd->exec("UPDATE client SET actif = 0 WHERE id_question = $id_question");
}

?>
